﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace Testqqq
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            ultraGridPaging1.InitializePages += new UltraGridPaging.UltraGridPaging.ChangingHandler(ultraGridPaging1_InitializePages);

            DataTable dt = new DataTable();
            dt.Columns.Add("A");
            dt.Columns.Add("B");
            dt.Columns.Add("C");
            dt.Columns.Add("D");
            dt.Columns.Add("E");
            dt.Columns.Add("F");
            dt.Columns.Add("G");
            dt.Columns.Add("H");
            dt.Columns.Add("I");
            dt.Columns.Add("J");
            
            //// Test Sort
            //dt.Rows.Add("Test 1");
            //dt.Rows.Add("Test 5");
            //dt.Rows.Add("Test 6");
            //dt.Rows.Add("Test 4");
            //dt.Rows.Add("Test 2");
            //dt.Rows.Add("Test 3");
            //dt.Rows.Add("Test 8");
            //dt.Rows.Add("Test 9");
            //dt.Rows.Add("Test 7");

            for (int k = 0; k < 100000; k++)
            {
                dt.Rows.Add("Test " + k.ToString(), k.ToString(), k.ToString(), "Description " + k.ToString(), "Value " + k.ToString(), "Data " + k.ToString(), "Data " + k.ToString(), "Data " + k.ToString(), "Data " + k.ToString(), "Data " + k.ToString());
            }
            ultraGridPaging1.DataSource = dt;
            ultraGridPaging1.GridLayout.Appearance.BackColor = Color.LightYellow;
            ultraGridPaging1.GridLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortSingle;
        }

        void ultraGridPaging1_InitializePages(object sender, UltraGridPaging.PageEventArgs PageEventArgs)
        {
            //Debug.WriteLine("InitializePages event. Rows per page: " + PageEventArgs.RowsPerPage.ToString());
        }
    }
}
