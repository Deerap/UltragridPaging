﻿namespace Testqqq
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ultraGridPaging1 = new UltraGridPaging.UltraGridPaging();
            this.SuspendLayout();
            // 
            // ultraGridPaging1
            // 
            this.ultraGridPaging1.Caption = "UltraGridPaging";
            this.ultraGridPaging1.DataMember = null;
            this.ultraGridPaging1.DataSource = null;
            this.ultraGridPaging1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ultraGridPaging1.DockNavigator = System.Windows.Forms.DockStyle.Top;
            this.ultraGridPaging1.GridLayout = ((Infragistics.Win.UltraWinGrid.UltraGridLayout)(resources.GetObject("ultraGridPaging1.GridLayout")));
            this.ultraGridPaging1.Location = new System.Drawing.Point(0, 0);
            this.ultraGridPaging1.Name = "ultraGridPaging1";
            this.ultraGridPaging1.RowsPerPage = 17;
            this.ultraGridPaging1.Size = new System.Drawing.Size(611, 426);
            this.ultraGridPaging1.TabIndex = 0;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(611, 426);
            this.Controls.Add(this.ultraGridPaging1);
            this.Name = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private UltraGridPaging.UltraGridPaging ultraGridPaging1;












    }
}

